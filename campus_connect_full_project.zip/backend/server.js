
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const multer = require("multer");
const path = require("path");

const Report = require("./models/Report");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

mongoose.connect("mongodb://127.0.0.1:27017/campus_connect")
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage: storage });

app.post("/api/report", upload.single("image"), async (req,res)=>{
  try{
    const {title,description,lat,lng} = req.body;

    const report = new Report({
      title,
      description,
      lat,
      lng,
      image: req.file ? req.file.filename : null
    });

    await report.save();
    res.json({message:"Report submitted"});

  }catch(err){
    res.status(500).json(err);
  }
});

app.get("/api/reports", async(req,res)=>{
  const reports = await Report.find();
  res.json(reports);
});

app.get("/api/reports/:id", async(req,res)=>{
  const report = await Report.findById(req.params.id);
  res.json(report);
});

app.listen(5000, ()=>console.log("Server running on port 5000"));
