
const mongoose = require("mongoose");

const ReportSchema = new mongoose.Schema({
  title:String,
  description:String,
  lat:Number,
  lng:Number,
  image:String,
  createdAt:{
    type:Date,
    default:Date.now
  }
});

module.exports = mongoose.model("Report",ReportSchema);
